This directory keeps submodules used in libjulius.  They are built into libjulius.a.

- libfvad: https://github.com/dpirch/libfvad  (copy of master at 2018/12/30 19:38)

See LICENSE term under each directory for licensing issue.

If you want to build Julius without libfvad, run configure with "--disable-libfvad"
